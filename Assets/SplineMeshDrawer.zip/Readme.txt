Version : 1.0.3

Thanks for buy!

this asset include these menu
1.GameObject/2D Object/Line/WorldLine
2.GameObject/2D Object/Line/UILine
3.GameObject/2D Object/Line/GizmoLine


creator
Kim giwon (https://github.com/geniikw) ,(geniikw@gmail.com)

reference 
https://github.com/HTD/FastBezier
https://en.wikipedia.org/wiki/Bezier_curve