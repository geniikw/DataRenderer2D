﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace geniikw.UIMeshLab
{
    public interface ISpline
    {
        Spline Line { get; }
    }
}